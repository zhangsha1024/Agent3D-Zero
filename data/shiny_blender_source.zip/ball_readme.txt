The 'ball' scene was rendered in Python using a Phong BRDF, which is not available in Blender.

The geometry is a unit sphere, and the two rough "bands" are at (abs(x) < 0.15) || (abs(y) < 0.15). The rough
bands have a Phong exponent of 50, with the rest set to 500. The environment map used is from the forest.exr
file which comes with Blender, and can also be found online, e.g., at https://polyhaven.com/a/ninomaru_teien.
